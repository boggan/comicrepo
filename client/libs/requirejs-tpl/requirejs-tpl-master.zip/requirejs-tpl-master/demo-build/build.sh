#!/bin/sh

rm -rf ../demo-build
node ../tools/r.js -o build.js
